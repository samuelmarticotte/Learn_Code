(ns clojure-query.core
  (:require [clojure.java.io :as io]))
;;============================WELCOME BANNERS
(defn banner [title]
  (println "==================================\\n" title "\\n=================================="))
(defn usage [message]
  (println "Usage:\n" message))
;;============================READ AND CLEAN DATA
(defn clean [strings noise]
  ;;remove noise from list of strings
  (for [s strings]
                (-> s ((apply comp
                              (for [n noise] #(.replace %1 n "")))))))
;;============================QUESTIONS
(defn ask-question [question ans-one ans-two]
  ;;ask a question, takes two possible answers and returns one.
  (def ans "?")
  (while (and (not= ans ans-one) (not= ans ans-two))        ;;while not one answer or the other
    (println question)
    (def ans (read-line)))
  ans)
;;============================BUILD QUERY
(defn build-query [items noise]
  ;;This functions takes a list of items, a field and noise to be removed, and returns a formatted query
  (if (= (ask-question "Do you want some regexes? (y/n): " "y" "n") "y")
    (def regexed-list (for [i items] (str "/.*" i ".*/")))
    (def regexed-list (for [i items] (str "\"" i "\""))))
  (if (= (ask-question "Do you want AND or OR:" "AND" "OR") "AND")
    (def booleaned-list (interpose "AND" regexed-list))
    (def booleaned-list (interpose "OR" regexed-list)))
  (if (= (ask-question "Clean ALL special characters? (y/n): " "y" "n") "y")
    (def cleaned-list (clean booleaned-list noise))
    (def cleaned-list booleaned-list))
    cleaned-list)
;;============================MAIN DEF
(defn -main []
  ;;Welcome message
  (banner "Welcome to BELL QUICK QUERY MAKER")
  (usage "Supply a list of iocs called list.txt")
  ;;Read iocs
  (def iocs (clojure.string/split-lines (slurp "/Volumes/128HDD/6_Programming/0_Git_Repositories/Learn_Code/21_Clojure/clojure-query/resources/list.txt")))
  (def noise ["!" "$" "" "[" "-" "(" ")" "{" "}" "," "\"" "?" "<" ">" "@" "`" "^"])
  (def field "ips:")
  ;;Ask for input
  (println field (build-query iocs noise)))
;;============================MAIN RUN
(-main)